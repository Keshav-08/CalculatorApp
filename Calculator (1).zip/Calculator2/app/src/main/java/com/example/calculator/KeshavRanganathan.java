package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.StringTokenizer;


public class KeshavRanganathan extends AppCompatActivity {
    Button button;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button button7;
    Button button8;
    Button button9;
    Button button10;
    Button button11;
    Button button12;
    Button button13;
    Button button14;
    Button button15;
    Button button16;
    TextView textview4;
    String formula;
    StringTokenizer st;
    double answer;
    int more = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);
        button10 = findViewById(R.id.button10);
        button11 = findViewById(R.id.button11);
        button12 = findViewById(R.id.button12);
        button13 = findViewById(R.id.button13);
        button14 = findViewById(R.id.button14);
        button15 = findViewById(R.id.button15);
        button16 = findViewById(R.id.button16);
        textview4 = findViewById(R.id.textView4);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textview4.setText("");


            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = textview4.getText().toString();
                a = a + "0";

                textview4.setText(a);

            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                formula = textview4.getText().toString();


                answer = getResult(formula);

                if (answer == Double.POSITIVE_INFINITY)
                    textview4.setText("error");
                else
                    textview4.setText(String.valueOf(answer));
            }
        });


        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = (String) textview4.getText();
                textview4.setText(a + "/");
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = textview4.getText().toString();
                a = a + "7";

                textview4.setText(a);
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = textview4.getText().toString();
                a = a + "8";
                textview4.setText(a);

            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = textview4.getText().toString();
                a = a + "9";

                textview4.setText(a);
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = (String) textview4.getText();
                textview4.setText(a + "*");
            }
        });

        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = textview4.getText().toString();
                a = a + "4";

                textview4.setText(a);

            }
        });

        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = textview4.getText().toString();
                a = a + "5";

                textview4.setText(a);

            }
        });

        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = textview4.getText().toString();
                a = a + "6";

                textview4.setText(a);

            }
        });

        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = (String) textview4.getText();
                textview4.setText(a + "-");
            }
        });

        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = textview4.getText().toString();
                a = a + "1";

                textview4.setText(a);


            }
        });

        button14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = textview4.getText().toString();
                a = a + "2";

                textview4.setText(a);


            }
        });

        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = textview4.getText().toString();
                a = a + "3";

                textview4.setText(a);


            }
        });

        button16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = (String) textview4.getText();
                textview4.setText(a + "+");
            }
        });
    }

    ;

    public double getResult(String formula) {
        String first, second;
        double result, lh, rh;
        result = 0;
        more = -1;
        while (more != 0) {
            st = new StringTokenizer(formula, "\\+");
            if (st.countTokens() > 1) {
                first = st.nextToken();
                second = st.nextToken();



                more = 0;

                if (first.contains("*") || first.contains("/") || first.contains("+") || first.contains("-")) {
                    more += 1;
                    formula = first;
                }
                if (second.contains("*") || second.contains("/") || second.contains("+") || second.contains("-")) {
                    more += 2;
                    formula = second;
                }

                if (more == 0) {
                    result = Double.parseDouble(first) +
                            Double.parseDouble(second);
                    while (st.hasMoreTokens())
                        result = result + Double.parseDouble(st.nextToken());
                }
                else if (more == 1) {
                    rh = Double.parseDouble(second);
                    result = getResult(first) + rh;
                }
                else if (more == 2) {
                    lh = Double.parseDouble(first);
                    result = lh + getResult(second);
                }
                else if (more == 3) {
                    result = getResult(first) + getResult(second);
                }

            } else {
                st = new StringTokenizer(formula, "\\-");

                if (st.countTokens() > 1) {
                    first = st.nextToken();
                    second = st.nextToken();


                    more = 0;

                    if (first.contains("*") || first.contains("/") || first.contains("+") || first.contains("-")) {
                        more += 1;
                        formula = first;
                    }
                    if (second.contains("*") || second.contains("/") || second.contains("+") || second.contains("-")) {
                        more += 2;
                        formula = second;
                    }

                    if (more == 0) {
                        result = Double.parseDouble(first) -
                                Double.parseDouble(second);
                        while (st.hasMoreTokens())
                            result = result - Double.parseDouble(st.nextToken());
                    }
                    else if (more == 1) {
                        rh = Double.parseDouble(second);
                        result = getResult(first) - rh;
                    }
                    else if (more == 2) {
                        lh = Double.parseDouble(first);
                        result = lh - getResult(second);
                    }
                    else if (more == 3) {
                        result =  getResult(first) - getResult(second);
                    }

                } else {
                    st = new StringTokenizer(formula, "\\/");

                    if (st.countTokens() > 1) {
                        first = st.nextToken();
                        second = st.nextToken();


                        more = 0;

                        if (first.contains("*") || first.contains("/") || first.contains("+") || first.contains("-")) {
                            more += 1;
                            formula = first;
                        }
                        if (second.contains("*") || second.contains("/") || second.contains("+") || second.contains("-")) {
                            more += 2;
                            formula = second;
                        }

                        if (more == 0) {
                            result = Double.parseDouble(first) /
                                    Double.parseDouble(second);
                            while (st.hasMoreTokens())
                                result = result / Double.parseDouble(st.nextToken());
                        }
                        else if (more == 1) {
                            rh = Double.parseDouble(second);
                            if (rh == 0)
                                result = Double.POSITIVE_INFINITY;
                            else
                                result = getResult(first) / rh;
                        }
                        else if (more == 2) {
                            lh = Double.parseDouble(first);
                            rh = getResult(second);
                            if (rh == 0)
                                result = Double.POSITIVE_INFINITY;
                            else
                                result = lh / rh;
                        }
                        else if (more == 3) {
                            lh = getResult(first);
                            rh = getResult(second);
                            if (rh == 0)
                                result = Double.POSITIVE_INFINITY;
                            else
                                result = lh / rh;
                        }

                    } else {
                        st = new StringTokenizer(formula, "\\*");

                        if (st.countTokens() > 1) {
                            first = st.nextToken();
                            second = st.nextToken();

                            more = 0;

                            if (first.contains("*") || first.contains("/") || first.contains("+") || first.contains("-")) {
                                more += 1;
                                formula = first;
                            }
                            if (second.contains("*") || second.contains("/") || second.contains("+") || second.contains("-")) {
                                more += 2;
                                formula = second;
                            }

                            if (more == 0) {
                                result = Double.parseDouble(first) *
                                        Double.parseDouble(second);
                                while (st.hasMoreTokens())
                                    result = result * Double.parseDouble(st.nextToken());
                            }
                            else if (more == 1) {
                                rh = Double.parseDouble(second);
                                result = getResult(first) * rh;
                            }
                            else if (more == 2) {
                                lh = Double.parseDouble(first);
                                result = lh * getResult(second);
                            }
                            else if (more == 3)
                                result = getResult(first)*getResult(second);


                        } else more = 0;
                    }
                }
            }
        }
        return result;
    }
}





























































